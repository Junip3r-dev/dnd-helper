function stab(){
   var audio = new Audio("scripts/sounds/sword-slash-with-metallic-impact-185435.mp3");
   audio.play();
};
function arrow(){
    var audio = new Audio("scripts/sounds/arrow-body-impact-146419.mp3");
    audio.play();
 };
 function block(){
    var audio = new Audio("scripts/sounds/sword-slash-with-metal-shield-impact-185433.mp3");
    audio.play();
 };
 function hurt(){
    var audio = new Audio("scripts/sounds/homemadeoof-47509.mp3");
    audio.play();
 };
 function death(){
    var audio = new Audio("scripts/sounds/no-luck-too-bad-disappointing-sound-effect-112943.mp3");
    audio.play();
 };
